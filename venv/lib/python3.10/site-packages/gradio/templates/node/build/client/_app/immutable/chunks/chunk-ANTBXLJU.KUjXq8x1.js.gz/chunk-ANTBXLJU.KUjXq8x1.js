import{_ as l}from"./mermaid.core.Dux0yjhv.js";function m(e,c){var i,t,o;e.accDescr&&((i=c.setAccDescription)==null||i.call(c,e.accDescr)),e.accTitle&&((t=c.setAccTitle)==null||t.call(c,e.accTitle)),e.title&&((o=c.setDiagramTitle)==null||o.call(c,e.title))}l(m,"populateCommonDb");export{m as p};
//# sourceMappingURL=chunk-ANTBXLJU.KUjXq8x1.js.map
