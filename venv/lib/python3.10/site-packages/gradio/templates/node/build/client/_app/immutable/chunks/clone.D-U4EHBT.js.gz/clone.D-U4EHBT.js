import{b as r}from"./_baseUniq.As8X8N8o.js";var e=4;function a(o){return r(o,e)}export{a as c};
//# sourceMappingURL=clone.D-U4EHBT.js.map
