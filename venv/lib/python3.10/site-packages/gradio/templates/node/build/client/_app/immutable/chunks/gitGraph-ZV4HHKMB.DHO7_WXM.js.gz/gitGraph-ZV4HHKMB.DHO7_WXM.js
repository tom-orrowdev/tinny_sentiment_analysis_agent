import{G as a,f as G}from"./mermaid-parser.core.CGAvxefi.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-ZV4HHKMB.DHO7_WXM.js.map
