import{P as c,a as r}from"./mermaid-parser.core.CGAvxefi.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-HUATNLJX.BC4kOlLz.js.map
