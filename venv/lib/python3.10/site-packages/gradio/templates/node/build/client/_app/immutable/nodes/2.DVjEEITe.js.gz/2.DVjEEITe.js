import{a2 as e,a1 as n}from"../chunks/2.C68MJXGw.js";export{e as component,n as universal};
//# sourceMappingURL=2.DVjEEITe.js.map
