import{x as o}from"./2.C68MJXGw.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.BKw9YJVn.js.map
